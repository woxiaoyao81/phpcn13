<?php 
namespace app\controller;
class Index {

	public function index(){

		$model = new \app\model\Content();
		$content = $model -> getContent();

		$view = new \mylib\View();
		$view -> assign('content', $content);
		$tpl = APP_PATH . 'view/index/index.php';
		return $view -> fetch($tpl);
	}

}