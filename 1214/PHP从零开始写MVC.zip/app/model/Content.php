<?php 
namespace app\model;
class Content
{
	
	public function getContent(){
		return [
			'title'=>'hello MVC！',
			'body'=>'这是我的第一个PHP学习框架！',
		];
	}
}