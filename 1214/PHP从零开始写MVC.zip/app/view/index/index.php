<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo $content['title'] ?></title>
</head>
<body>
	<h1><?php echo $content['title'] ?></h1>
	<p><?php echo $content['body'] ?></p>
</body>
</html>