<?php 
// 定义APP目录
define('APP_PATH', __DIR__ . '/../app/');
// 引入框架
require_once '../mylib/Loader.php';