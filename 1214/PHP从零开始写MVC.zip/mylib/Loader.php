<?php 
// 设置时区
date_default_timezone_set('PRC');

// 注册自动加载
spl_autoload_register(function($class){
	$class_path = str_replace('\\', DIRECTORY_SEPARATOR, $class);
	if (0 === strpos($class_path, 'mylib')) {
		$file = dirname(__DIR__) . DIRECTORY_SEPARATOR . $class_path . '.php';
	} elseif (0 === strpos($class_path, 'app')) {
		$file = dirname(APP_PATH) . DIRECTORY_SEPARATOR . $class_path . '.php';
	}
	if (is_file($file)) {
		require_once $file;
		if(class_exists($class, false)) {
			return true;
		}
	}
	return false;
});

// 执行APP
\mylib\App::run();