<?php 
namespace mylib;
class App{

	public static function run(){

		$controller = isset($_GET['c'])&&$_GET['c'] ? $_GET['c']:'Index';
		$action = isset($_GET['a'])&&$_GET['a'] ? $_GET['a'] : 'index';

		$class = '\\app\\controller\\' . $controller;

		echo (new $class()) -> $action();
	}
}