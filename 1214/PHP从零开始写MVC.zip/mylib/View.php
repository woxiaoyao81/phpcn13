<?php 
namespace mylib;
class View
{
	public  $data = [];

	public function __construct() {
	}

	public function assign($field, $value) {
		$this -> data[$field] = $value;
	}

	public function fetch($tpl){
		ob_start();
		ob_implicit_flush(0);
		if (!is_null($this -> data)) {
			extract($this -> data, EXTR_OVERWRITE);
		}
		require $tpl;
		return ob_get_clean();
	}
}